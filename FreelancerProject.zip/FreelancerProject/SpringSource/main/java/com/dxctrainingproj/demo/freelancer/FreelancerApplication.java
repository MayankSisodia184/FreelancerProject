package com.dxctrainingproj.demo.freelancer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FreelancerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FreelancerApplication.class, args);
		
		System.out.println("SERVICE STARTED");
	}

}

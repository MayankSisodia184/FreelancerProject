import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchProjectAdminComponent } from './search-project-admin.component';

describe('SearchProjectAdminComponent', () => {
  let component: SearchProjectAdminComponent;
  let fixture: ComponentFixture<SearchProjectAdminComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchProjectAdminComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchProjectAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

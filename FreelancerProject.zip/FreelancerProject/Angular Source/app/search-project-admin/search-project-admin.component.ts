import { FreelancerService } from './../freelancer.service';
import { Component, OnInit } from '@angular/core';
import { PostNewProject } from '../PostNewProject.model';
import { ActivatedRoute } from '@angular/router';
import { AwardedProjects } from '../AwardedProjects.model';
import { AppliedProjects } from '../AppliedProjects.model';

@Component({
  selector: 'app-search-project-admin',
  templateUrl: './search-project-admin.component.html',
  styleUrls: ['./search-project-admin.component.css']
})
export class SearchProjectAdminComponent implements OnInit {
  projects: PostNewProject[];
  current = 0;
  search: string;
  project = new PostNewProject();
  applied: AppliedProjects[] = [];
  awardedProject = new AwardedProjects;
  selectedCandidates = [] as any;

  constructor(private flserv: FreelancerService, private router: ActivatedRoute) { }

  ngOnInit() {
    this.router.params.subscribe(params => {
      this.search = params['test'];
     }
    );
   // console.log(this.search);
       this.flserv.searchProjectByName(this.search).subscribe(
         data => this.projects = data,
         error => console.log(error)
       );
  }

  OnChange(email: any, isChecked: boolean) {
    if (isChecked) {
      this.selectedCandidates.push(email);
   // console.log(email);
   } else {
       this.selectedCandidates.splice(this.selectedCandidates.indexOf(email), 1);
       // console.log('unchecked ' + email);
    }
   // console.log(this.selectedCandidates);
  }



  Award() {
    this.flserv.updateStatusAsClose(this.project.projectId).subscribe(
      data => console.log(data),
      error => console.log(error)
      );

      for (let i = 0; i < this.applied.length; i++) {
          this.flserv.updateStatusAsRejected( this.applied[i].freelancerEmail, this.project.projectId).subscribe(
            data => console.log(data),
            error => console.log(error)
          );
      }
    for (let i = 0; i < this.selectedCandidates.length; i++) {
      const email = this.selectedCandidates[i];
      console.log(email);
       this.awardedProject.freelancerEmail = email;
      this.awardedProject.projectCost = this.project.projectCost;
      this.awardedProject.projectDuration = this.project.projectDuration;
      this.awardedProject.projectId = this.project.projectId;
      this.awardedProject.projectName = this.project.projectName;
      this.flserv.saveAwardedProject(this.awardedProject).subscribe(
        data => console.log(data),
        error => console.log(error)
      );
      this.flserv.updateStatusAsAccepted(email, this.project.projectId).subscribe(
        data => console.log(data),
        error => console.log(error)
      );
     }
     alert('Project Awarded');
 }
  close(projectId: number) {
    this.flserv.updateStatusAsClose(projectId).subscribe(
      data => console.log(data),
      error => console.log(error)
    );
    alert('Project Closed');
  }
  getProjectById(projectId: number) {
    this.flserv.getProjectById(projectId).subscribe(
      data => this.project = data,
      error => console.log(error)
    );
}

update() {
this.flserv.updateProject(this.project).subscribe(
  data => console.log(data),
  error => console.log(error)
);
alert('Project Updated');
}
}

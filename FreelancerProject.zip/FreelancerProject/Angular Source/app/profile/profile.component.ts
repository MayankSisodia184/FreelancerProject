import { Component, OnInit } from '@angular/core';
import { Freelancer } from '../freelancer.model';
import { FreelancerService } from '../freelancer.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  freelancer: Freelancer = {	'freelancerName': '', 'freelancerEmail': '', 'freelancerPhone': 0, 'freelancerPassword': '',
  'securityQuestion': '',
	'securityAnswer': '',
	'freelancerSkills': '',
  'freelancerExperience': ''};
  email;
  constructor(private flserv: FreelancerService) { }

  ngOnInit() {
      this.email = localStorage.getItem('email');
      this.flserv.viewProfile(this.email).subscribe(
        data => this.freelancer = data,
        error => console.log(error)
      );
  }
 update() {
   this.flserv.updateFreelancer(this.freelancer).subscribe(
     data => console.log(data),
     error => console.log(error)
   );
   alert('Profile Updated');
 }

}

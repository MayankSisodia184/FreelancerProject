export class AppliedProjects {
  freelancerEmail: string;
  projectId: number;
  projectName: string;
  applicantStatus: string;
}

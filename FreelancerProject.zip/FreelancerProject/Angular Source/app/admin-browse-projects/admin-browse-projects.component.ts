import { AwardedProjects } from './../AwardedProjects.model';
import { Freelancer } from './../freelancer.model';
import { AppliedProjects } from './../AppliedProjects.model';
import { PostNewProject } from './../PostNewProject.model';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FreelancerService } from '../freelancer.service';

@Component({
  selector: 'app-admin-browse-projects',
  templateUrl: './admin-browse-projects.component.html',
  styleUrls: ['./admin-browse-projects.component.css']
})
export class AdminBrowseProjectsComponent implements OnInit {
  projects: PostNewProject[];
  current = 0;
  project = new PostNewProject();
  applied: AppliedProjects[] = [];
  awardedProject = new AwardedProjects;
  selectedCandidates = [] as any;

emails: any[];

  constructor(private flserv: FreelancerService) {
    this.selectedCandidates = [];
   }

  ngOnInit() {
    this.flserv.viewAllProjects().subscribe(
      data => this.projects = data,
      error => console.log(error)
    );
  }

  OnChange(email: any, isChecked: boolean) {
    if (isChecked) {
      this.selectedCandidates.push(email);
   // console.log(email);
   } else {
       this.selectedCandidates.splice(this.selectedCandidates.indexOf(email), 1);
       // console.log('unchecked ' + email);
    }
   // console.log(this.selectedCandidates);
  }

  Award() {
    this.flserv.updateStatusAsClose(this.project.projectId).subscribe(
      data => console.log(data),
      error => console.log(error)
      );

      for (let i = 0; i < this.applied.length; i++) {
          this.flserv.updateStatusAsRejected( this.applied[i].freelancerEmail, this.project.projectId).subscribe(
            data => console.log(data),
            error => console.log(error)
          );
      }

     for (let i = 0; i < this.selectedCandidates.length; i++) {
       const email = this.selectedCandidates[i];
        this.awardedProject.freelancerEmail = email;
       this.awardedProject.projectCost = this.project.projectCost;
       this.awardedProject.projectDuration = this.project.projectDuration;
       this.awardedProject.projectId = this.project.projectId;
       this.awardedProject.projectName = this.project.projectName;
       this.flserv.saveAwardedProject(this.awardedProject).subscribe(
         data => console.log(data),
         error => console.log(error)
       );
       this.flserv.updateStatusAsAccepted(email, this.project.projectId).subscribe(
         data => console.log(data),
         error => console.log(error)
       );
      }
      alert('Project Awarded');
  }

  close(projectId: number) {
    this.flserv.updateStatusAsClose(projectId).subscribe(
      data => console.log(data),
      error => console.log(error)
    );
    alert('Project Closed');
  }

  getProjectById(projectId: number) {
        this.flserv.getProjectById(projectId).subscribe(
          data => this.project = data,
          error => console.log(error)
        );
  }

  getProjectByIdandFl(projectId: number) {
    this.flserv.getProjectById(projectId).subscribe(
      data => this.project = data,
      error => console.log(error)
    );
    this.flserv.getAppliedProjectById(projectId).subscribe(
      data => this.applied = data,
      error => console.log(error)
    );
}

  update() {
    this.flserv.updateProject(this.project).subscribe(
      data => console.log(data),
      error => console.log(error)
    );
    alert('Project Updated');
  }
}

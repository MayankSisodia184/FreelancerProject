import { Router } from '@angular/router';
import { FreelancerService } from './../freelancer.service';
import { Component, OnInit } from '@angular/core';
import { Freelancer } from '../freelancer.model';

@Component({
  selector: 'app-freelancer-home',
  templateUrl: './freelancer-home.component.html',
  styleUrls: ['./freelancer-home.component.css']
})
export class FreelancerHomeComponent implements OnInit {
name;
email;
  search;
  freelancer: Freelancer = {	'freelancerName': '', 'freelancerEmail': '', 'freelancerPhone': 0, 'freelancerPassword': '',
  'securityQuestion': '',
	'securityAnswer': '',
	'freelancerSkills': '',
  'freelancerExperience': ''};
  constructor(private flserv: FreelancerService, private rout: Router) {
   }

  ngOnInit() {
    this.email = localStorage.getItem('email');
    if (this.email === null) {
        this.rout.navigateByUrl('/userlogin');
    } else {
    this.flserv.viewProfile(this.email).subscribe(
      data => {this.freelancer = data;
        this.name = this.freelancer.freelancerName;
      },
      error => console.log(error)
    );
  }
}

  signoff() {
    localStorage.clear();
    this.rout.navigateByUrl('/userlogin');
  }
  }

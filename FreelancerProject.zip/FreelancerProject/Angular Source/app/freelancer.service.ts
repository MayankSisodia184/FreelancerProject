import { AppliedProjects } from './AppliedProjects.model';
import { AwardedProjects } from './AwardedProjects.model';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PostNewProject } from './PostNewProject.model';
import { Freelancer } from './freelancer.model';

@Injectable({
  providedIn: 'root'
})
export class FreelancerService {

  constructor(private http: HttpClient) { }
  saveFreelancer( freelancer: Freelancer) {
    return this.http.post<any>('http://localhost:1035/freelancer', freelancer);
  } // done

  updateFreelancer( freelancer: Freelancer) {
    return this.http.put<any>('http://localhost:1035/freelancer', freelancer);
  }  // done

  freelancerLogin(freelancerEmail: string, freelancerPassword: string ){

    return this.http.get<boolean>(`http://localhost:1035/login/${freelancerEmail}/${freelancerPassword}`);
  }  // done

  viewProfile(freelancerEmail: string){
    return this.http.get<any>(`http://localhost:1035/freelancer/${freelancerEmail}`);
  }  // done


  saveProject( project: PostNewProject) {
    return this.http.post<any>('http://localhost:1035/project', project);
  }  // done

  updateProject( project: PostNewProject) {
    return this.http.put<any>('http://localhost:1035/project', project);

  } // done

  getProjectById(projectId: number) {
    return this.http.get<PostNewProject>(`http://localhost:1035/project/${projectId}`);
  } // done

  searchProjectByName(projectName: string){
    return this.http.get<PostNewProject[]>(`http://localhost:1035/getproject/${projectName}`);
  } // done

  viewAllProjects() {
    return this.http.get<PostNewProject[]>('http://localhost:1035/getallproject');
  } // done

  updateStatusAsClose(projectId: number) {
    return this.http.put<any>(`http://localhost:1035/updatestatuswithid/${projectId}`, projectId );
  } // done

  getAwardedProjectByEmail(freelancerEmail: string) {
    return this.http.get<AwardedProjects[]>(`http://localhost:1035/awardproject/${freelancerEmail}`);
  } // done

  viewAllAwardedProjects() {
    return this.http.get<AwardedProjects[]>('http://localhost:1035/allawardedprojects');
  } // done

  saveAppliedProject(project: AppliedProjects) {
    return this.http.post<any>('http://localhost:1035/appliedproject', project);
  } // done

  getAppliedProjectByEmail(freelancerEmail: string){
    return this.http.get<AppliedProjects[]>(`http://localhost:1035/appliedprojectbyemail/${freelancerEmail}`);
  } // done

  viewAllAppliedProjects() {
    return this.http.get<AppliedProjects[]>('http://localhost:1035/allappliedprojects');
  } // done

  getAppliedProjectById(projectId: number) {
    return this.http.get<AppliedProjects[]>(`http://localhost:1035/appliedprojectbyid/${projectId}`);
  } // done

  updateStatusAsAccepted(freelancerEmail: string, projectId: number) {
    return this.http.put<any>(`http://localhost:1035/updatestatusasaccepted/${freelancerEmail}/${projectId}`, freelancerEmail );
  } // done

  saveAwardedProject(project: AwardedProjects) {
    return this.http.post<any>('http://localhost:1035/awardproject', project);
  } // done

   updatePassword(freelancerEmail: string, newPassword: string) {
     return this.http.put<any>(`http://localhost:1035/updatepassword/${freelancerEmail}/${newPassword}`, freelancerEmail);
   } // done

    checkSecurityAnswer(freelancerEmail: string, securityAnswer: string) {
      return this.http.get<boolean>(`http://localhost:1035/checkanswer/${freelancerEmail}/${securityAnswer}`);
    } // done

    getFreelancerProjects(freelancerEmail: string) {
         return this.http.get<PostNewProject[]>(`http://localhost:1035/getfreelancerprojects/${freelancerEmail}`);
    } // done

    getAllFreelancers() {
      return this.http.get<Freelancer[]>('http://localhost:1035/getallfreelancers');
    } // done

    getAllFreelancersEmail() {
      return this.http.get<string[]>('http://localhost:1035/getallfreelancersemail');
    }  // done

    updateStatusAsRejected(freelancerEmail: string, projectId: number) {
      return this.http.put<any>(`http://localhost:1035/updatestatusasrejected/${freelancerEmail}/${projectId}`, freelancerEmail );
    }

}

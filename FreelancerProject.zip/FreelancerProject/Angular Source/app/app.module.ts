import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FreelancerRegistrationComponent } from './freelancer-registration/freelancer-registration.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { FreelancerLoginComponent } from './freelancer-login/freelancer-login.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ProfileComponent } from './profile/profile.component';
import { FreelancerHomeComponent } from './freelancer-home/freelancer-home.component';
import { AwardedProjectsComponent } from './awarded-projects/awarded-projects.component';
import { AppliedProjectsComponent } from './applied-projects/applied-projects.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { FirstPageComponent } from './first-page/first-page.component';
import { FreelancerBrowseProjectsComponent } from './freelancer-browse-projects/freelancer-browse-projects.component';
import { AdminBrowseProjectsComponent } from './admin-browse-projects/admin-browse-projects.component';
import { PostNewProjectComponent } from './post-new-project/post-new-project.component';
import { HttpClientModule } from '@angular/common/http';
import { SearchProjectFreelancerComponent } from './search-project-freelancer/search-project-freelancer.component';
import { SearchProjectAdminComponent } from './search-project-admin/search-project-admin.component';
import { AdminAwardedProjectsComponent } from './admin-awarded-projects/admin-awarded-projects.component';
import { AllFreelancersComponent } from './all-freelancers/all-freelancers.component';
import { AdminContentComponent } from './admin-content/admin-content.component';

@NgModule({
  declarations: [
    AppComponent,
    FreelancerRegistrationComponent,
    ForgotPasswordComponent,
    FreelancerLoginComponent,
    ChangePasswordComponent,
    ProfileComponent,
    FreelancerHomeComponent,
    AwardedProjectsComponent,
    AppliedProjectsComponent,
    AdminLoginComponent,
    AdminHomeComponent,
    FirstPageComponent,
    FreelancerBrowseProjectsComponent,
    AdminBrowseProjectsComponent,
    PostNewProjectComponent,
    SearchProjectFreelancerComponent,
    SearchProjectAdminComponent,
    AdminAwardedProjectsComponent,
    AllFreelancersComponent,
    AdminContentComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

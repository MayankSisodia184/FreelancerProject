export class PostNewProject {
  projectId: number;
  projectName: string;
  smallDescription: string;
  projectCost: number;
  projectDuration: string;
  projectStatus: string;
}

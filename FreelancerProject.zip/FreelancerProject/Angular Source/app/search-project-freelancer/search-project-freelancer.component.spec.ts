import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchProjectFreelancerComponent } from './search-project-freelancer.component';

describe('SearchProjectFreelancerComponent', () => {
  let component: SearchProjectFreelancerComponent;
  let fixture: ComponentFixture<SearchProjectFreelancerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchProjectFreelancerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchProjectFreelancerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
